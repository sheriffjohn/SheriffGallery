Please begin with reading the 1-JavaScriptGettingStarted2013.pdf document. 
It contains instructions on how to get started. 
