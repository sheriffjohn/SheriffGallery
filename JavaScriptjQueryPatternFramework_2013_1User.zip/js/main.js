﻿// Used in Single Page Application (SPA) demo app

(function () {
    require.config({
        paths: {
            "patterns": "patterns"
        }
    });
})();


