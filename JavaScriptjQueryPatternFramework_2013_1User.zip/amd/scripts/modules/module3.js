﻿define(function () {
    var go = function () {
        return "--- I am in Module3";
    };

    return { go: go };
});
